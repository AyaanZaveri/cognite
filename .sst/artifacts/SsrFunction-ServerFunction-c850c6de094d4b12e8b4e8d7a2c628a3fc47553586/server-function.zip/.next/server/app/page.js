(() => {
var exports = {};
exports.id = 1931;
exports.ids = [1931];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

"use strict";
module.exports = require("@prisma/client");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 93977:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs/promises");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 63477:
/***/ ((module) => {

"use strict";
module.exports = require("querystring");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 32046:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(88204);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(39385);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(76905);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 56784)), "/Users/ayaanzaveri/Code/cognition/app/page.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 200))).default(props)),(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 89876))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 42718)), "/Users/ayaanzaveri/Code/cognition/app/layout.tsx"],
'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6788)), "/Users/ayaanzaveri/Code/cognition/app/loading.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 200))).default(props)),(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 89876))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["/Users/ayaanzaveri/Code/cognition/app/page.tsx"];

    

    const originalPathname = "/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/page","pathname":"/","bundlePath":"app/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 20665:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 99365));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12543));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 82705, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 95741));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 95618, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 75215))

/***/ }),

/***/ 99365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_QuickCreate)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(79271);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-icons@4.10.1_react@18.2.0/node_modules/react-icons/tb/index.esm.js
var index_esm = __webpack_require__(96553);
// EXTERNAL MODULE: ./node_modules/.pnpm/@radix-ui+react-dialog@1.0.4_@types+react-dom@18.2.4_@types+react@18.2.6_react-dom@18.2.0_react@18.2.0/node_modules/@radix-ui/react-dialog/dist/index.mjs
var dist = __webpack_require__(82550);
// EXTERNAL MODULE: ./node_modules/.pnpm/@radix-ui+react-icons@1.3.0_react@18.2.0/node_modules/@radix-ui/react-icons/dist/react-icons.cjs.production.min.js
var react_icons_cjs_production_min = __webpack_require__(73835);
// EXTERNAL MODULE: ./lib/utils.ts
var utils = __webpack_require__(46006);
;// CONCATENATED MODULE: ./components/ui/dialog.tsx
/* __next_internal_client_entry_do_not_use__ Dialog,DialogTrigger,DialogContent,DialogHeader,DialogFooter,DialogTitle,DialogDescription auto */ 




const Dialog = dist/* Root */.fC;
const DialogTrigger = dist/* Trigger */.xz;
const DialogPortal = ({ className, ...props })=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Portal */.h_, {
        className: (0,utils.cn)(className),
        ...props
    });
DialogPortal.displayName = dist/* Portal */.h_.displayName;
const DialogOverlay = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Overlay */.aV, {
        ref: ref,
        className: (0,utils.cn)("fixed inset-0 z-50 bg-background/80 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
        ...props
    }));
DialogOverlay.displayName = dist/* Overlay */.aV.displayName;
const DialogContent = /*#__PURE__*/ react_.forwardRef(({ className, children, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(DialogPortal, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(DialogOverlay, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist/* Content */.VY, {
                ref: ref,
                className: (0,utils.cn)("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg md:w-full", className),
                ...props,
                children: [
                    children,
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist/* Close */.x8, {
                        className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(react_icons_cjs_production_min/* Cross2Icon */.Pxu, {
                                className: "h-4 w-4"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "sr-only",
                                children: "Close"
                            })
                        ]
                    })
                ]
            })
        ]
    }));
DialogContent.displayName = dist/* Content */.VY.displayName;
const DialogHeader = ({ className, ...props })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (0,utils.cn)("flex flex-col space-y-1.5 text-center sm:text-left", className),
        ...props
    });
DialogHeader.displayName = "DialogHeader";
const DialogFooter = ({ className, ...props })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (0,utils.cn)("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
        ...props
    });
DialogFooter.displayName = "DialogFooter";
const DialogTitle = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Title */.Dx, {
        ref: ref,
        className: (0,utils.cn)("text-lg font-semibold leading-none tracking-tight", className),
        ...props
    }));
DialogTitle.displayName = dist/* Title */.Dx.displayName;
const DialogDescription = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Description */.dk, {
        ref: ref,
        className: (0,utils.cn)("text-sm text-muted-foreground", className),
        ...props
    }));
DialogDescription.displayName = dist/* Description */.dk.displayName;


// EXTERNAL MODULE: ./components/ui/input.tsx
var input = __webpack_require__(40741);
// EXTERNAL MODULE: ./node_modules/.pnpm/zod@3.21.4/node_modules/zod/lib/index.mjs
var lib = __webpack_require__(43018);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-hook-form@7.45.2_react@18.2.0/node_modules/react-hook-form/dist/index.esm.mjs
var dist_index_esm = __webpack_require__(52653);
// EXTERNAL MODULE: ./node_modules/.pnpm/@hookform+resolvers@3.1.1_react-hook-form@7.45.2/node_modules/@hookform/resolvers/zod/dist/zod.mjs + 1 modules
var zod = __webpack_require__(54142);
// EXTERNAL MODULE: ./components/ui/form.tsx + 1 modules
var ui_form = __webpack_require__(50811);
// EXTERNAL MODULE: ./utils/scrapeSite.ts
var scrapeSite = __webpack_require__(60919);
// EXTERNAL MODULE: ./node_modules/.pnpm/langchain@0.0.120_@huggingface+inference@1.8.0_@pinecone-database+pinecone@0.1.6_axios@1.4.0__er7fjrb2atfoegdcu2uwzeynna/node_modules/langchain/text_splitter.js
var text_splitter = __webpack_require__(8962);
// EXTERNAL MODULE: ./node_modules/.pnpm/langchain@0.0.120_@huggingface+inference@1.8.0_@pinecone-database+pinecone@0.1.6_axios@1.4.0__er7fjrb2atfoegdcu2uwzeynna/node_modules/langchain/document_loaders/fs/pdf.js + 4 modules
var pdf = __webpack_require__(87367);
// EXTERNAL MODULE: ./node_modules/.pnpm/axios@1.4.0/node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(30386);
// EXTERNAL MODULE: ./node_modules/.pnpm/slugify@1.6.6/node_modules/slugify/slugify.js
var slugify = __webpack_require__(56630);
var slugify_default = /*#__PURE__*/__webpack_require__.n(slugify);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/link.js
var next_link = __webpack_require__(71930);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/navigation.js
var navigation = __webpack_require__(18424);
;// CONCATENATED MODULE: ./components/QuickCreate.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 

















const quickCreateFormSchema = lib/* object */.Ry({
    name: lib/* string */.Z_().min(3, {
        message: "Your name must be at least 3 characters long"
    }).max(30, {
        message: "It's a name, not a poem (max 30 characters)"
    }),
    websites: lib/* array */.IX(lib/* object */.Ry({
        value: lib/* string */.Z_().url({
            message: "Please enter a valid URL."
        })
    })).optional(),
    file: lib/* string */.Z_().optional()
});
const QuickCreate = ({ session })=>{
    const form = (0,dist_index_esm/* useForm */.cI)({
        resolver: (0,zod/* zodResolver */.F)(quickCreateFormSchema),
        mode: "onChange"
    });
    const { fields: websiteFields, append: appendWebsite } = (0,dist_index_esm/* useFieldArray */.Dq)({
        name: "websites",
        control: form.control
    });
    const [buttonStatus, setButtonStatus] = (0,react_.useState)({
        text: "Create",
        disabled: false,
        pulse: false
    });
    const router = (0,navigation.useRouter)();
    const [file, setFile] = (0,react_.useState)(null);
    async function getSources(sources) {
        try {
            if (sources?.sites.length > 0 || file) {
                setButtonStatus({
                    text: "Getting sources \uD83C\uDF0E",
                    disabled: true,
                    pulse: true
                });
                console.log(sources);
                const docs = [];
                if (sources?.sites && sources?.sites.length > 0) {
                    const siteText = await (0,scrapeSite/* scrapeSite */.T)(sources?.sites);
                    console.log(siteText);
                    const splitter = new text_splitter/* RecursiveCharacterTextSplitter */.s9({
                        chunkSize: 1000,
                        chunkOverlap: 200
                    });
                    const siteDocs = await splitter.createDocuments([
                        siteText
                    ]);
                    docs.push(...siteDocs);
                }
                if (file) {
                    const splitter = new text_splitter/* RecursiveCharacterTextSplitter */.s9({
                        chunkSize: 1000,
                        chunkOverlap: 200
                    });
                    const loader = new pdf/* PDFLoader */.u(file);
                    const pdfDocs = await loader.loadAndSplit(splitter);
                    docs.push(...pdfDocs);
                }
                // console.log(docs);
                setButtonStatus({
                    text: "Creating cog \uD83E\uDDE0",
                    disabled: true,
                    pulse: true
                });
                return docs;
            } else {
                setButtonStatus({
                    text: "No sources provided \uD83D\uDE22",
                    disabled: false,
                    pulse: false
                });
            }
        } catch (error) {
            console.log("error", error);
            setButtonStatus({
                text: "Error getting sources \uD83D\uDE22",
                disabled: false,
                pulse: false
            });
        }
    }
    async function onSubmit(data) {
        const sources = {
            sites: data.websites?.map((website)=>website.value),
            files: data.file
        };
        const theDocs = await getSources(sources);
        const updatedData = {
            name: data.name,
            docs: theDocs,
            slug: slugify_default()(data.name, {
                lower: true
            }),
            userId: session?.user?.id,
            tags: [],
            isPrivate: true,
            description: `Cog about ${data.name}`,
            imgUrl: "https://em-content.zobj.net/thumbs/240/apple/354/fire_1f525.png"
        };
        // console.log(updatedData);
        const response = await axios/* default */.Z.post(`/api/cog/create`, {
            data: updatedData
        }).then((res)=>{
            // console.log(res);
            setButtonStatus({
                text: "Cog created! \uD83C\uDF89",
                disabled: true,
                pulse: false
            });
            console.log(res);
            console.log(`/cog/${session?.user.username}/${res.data.cog.slug}`);
            router.push(`/cog/${session?.user.username}/${res.data.cog.slug}`);
        }).catch((err)=>{
            setButtonStatus({
                text: "Error creating cog \uD83D\uDE22",
                disabled: false,
                pulse: false
            });
            console.log(err);
        });
    }
    const handleFile = async (event)=>{
        if (event.target.files) {
            try {
                const file = event.target.files?.[0];
                if (file) {
                    const arrayBuffer = await file.arrayBuffer();
                    const blob = new Blob([
                        new Uint8Array(arrayBuffer)
                    ], {
                        type: file.type
                    });
                    setFile(blob);
                }
            } catch (err) {
                console.log("err", err);
            }
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Dialog, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(DialogTrigger, {
                asChild: true,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                    variant: "outline",
                    className: "space-x-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "Quick Create"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* TbBolt */.lbY, {
                            className: "h-4 w-4"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DialogContent, {
                className: "sm:max-w-[425px]",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DialogHeader, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(DialogTitle, {
                                children: "Quick Create"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(DialogDescription, {
                                children: "Quickly create a private cog ⚡️"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "grid gap-4 py-4",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* Form */.l0, {
                            ...form,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                className: "space-y-4",
                                onSubmit: form.handleSubmit(onSubmit),
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormField */.Wi, {
                                        control: form.control,
                                        name: "name",
                                        render: ({ field })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_form/* FormItem */.xJ, {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormLabel */.lX, {
                                                        children: "Name"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormControl */.NI, {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(input/* Input */.I, {
                                                            placeholder: "Name",
                                                            ...field
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormDescription */.pf, {
                                                        children: "Give it a quick name so you can find it later"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormMessage */.zG, {})
                                                ]
                                            })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            websiteFields.map((field, index)=>/*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormField */.Wi, {
                                                    control: form.control,
                                                    name: `websites.${index}.value`,
                                                    render: ({ field })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_form/* FormItem */.xJ, {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormLabel */.lX, {
                                                                    className: (0,utils.cn)(index !== 0 && "sr-only"),
                                                                    children: "Websites"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormDescription */.pf, {
                                                                    className: (0,utils.cn)(index !== 0 && "sr-only"),
                                                                    children: "Websites you want to train the cog on."
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormControl */.NI, {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(input/* Input */.I, {
                                                                        ...field
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormMessage */.zG, {})
                                                            ]
                                                        })
                                                }, field.id)),
                                            /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                                type: "button",
                                                variant: "outline",
                                                size: "sm",
                                                className: "mt-2",
                                                onClick: ()=>appendWebsite({
                                                        value: ""
                                                    }),
                                                children: "Add Website"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormField */.Wi, {
                                        control: form.control,
                                        name: "file",
                                        render: ({ field })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_form/* FormItem */.xJ, {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormLabel */.lX, {
                                                        children: "Files"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormControl */.NI, {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(input/* Input */.I, {
                                                            type: "file",
                                                            placeholder: "File",
                                                            ...field,
                                                            onChange: handleFile
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormDescription */.pf, {
                                                        children: "You can also upload a PDF"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormMessage */.zG, {})
                                                ]
                                            })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(DialogFooter, {
                                        children: session?.user?.id ? /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                            type: "submit",
                                            className: (0,utils.cn)(buttonStatus.disabled && "cursor-not-allowed"),
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: (0,utils.cn)(buttonStatus.pulse && "animate-pulse"),
                                                children: buttonStatus.text
                                            })
                                        }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/api/auth/signin",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                                    type: "button",
                                                    children: "Sign in to create a cog"
                                                })
                                            })
                                        })
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_QuickCreate = (QuickCreate);


/***/ }),

/***/ 60919:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   T: () => (/* binding */ scrapeSite)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(30386);

const scrapeSite = async (urls)=>{
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.post("/api/extract", {
            urls
        });
        console.log("response", response);
        return response.data.extracted_text;
    } catch (err) {
        if (err instanceof Error) {
            console.log(err.message);
        } else {
            console.log("Unexpected error", err);
        }
    }
};


/***/ }),

/***/ 56784:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./components/Logo.tsx
var Logo = __webpack_require__(91266);
// EXTERNAL MODULE: ./components/CoolBlur.tsx
var CoolBlur = __webpack_require__(97675);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1926);
;// CONCATENATED MODULE: ./components/QuickCreate.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/Users/ayaanzaveri/Code/cognition/components/QuickCreate.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const QuickCreate = (__default__);
// EXTERNAL MODULE: ./lib/auth.ts
var auth = __webpack_require__(66298);
// EXTERNAL MODULE: ./lib/prisma.ts
var prisma = __webpack_require__(43726);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/font/google/target.css?{"path":"components/cog/Card.tsx","import":"Space_Grotesk","arguments":[{"weight":["300","400","500","600","700"],"subsets":["latin"]}],"variableName":"space_grotesk"}
var Card_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_ = __webpack_require__(17927);
var Card_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_default = /*#__PURE__*/__webpack_require__.n(Card_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(49994);
// EXTERNAL MODULE: ./lib/utils.ts
var utils = __webpack_require__(90430);
;// CONCATENATED MODULE: ./components/ui/card.tsx



const Card = /*#__PURE__*/ react_shared_subset.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        ref: ref,
        className: (0,utils.cn)("rounded-lg border bg-card text-card-foreground shadow-sm", className),
        ...props
    }));
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ react_shared_subset.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        ref: ref,
        className: (0,utils.cn)("flex flex-col space-y-1.5 p-6", className),
        ...props
    }));
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ react_shared_subset.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("h3", {
        ref: ref,
        className: (0,utils.cn)("text-2xl font-semibold leading-none tracking-tight", className),
        ...props
    }));
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ react_shared_subset.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("p", {
        ref: ref,
        className: (0,utils.cn)("text-sm text-muted-foreground", className),
        ...props
    }));
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ react_shared_subset.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        ref: ref,
        className: (0,utils.cn)("p-6 pt-0", className),
        ...props
    }));
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ react_shared_subset.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        ref: ref,
        className: (0,utils.cn)(" flex items-center p-6 pt-0", className),
        ...props
    }));
CardFooter.displayName = "CardFooter";


// EXTERNAL MODULE: ./components/UserHoverCard.tsx
var UserHoverCard = __webpack_require__(37427);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/link.js
var next_link = __webpack_require__(33270);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/ui/avatar.tsx
var avatar = __webpack_require__(35982);
// EXTERNAL MODULE: ./node_modules/.pnpm/class-variance-authority@0.7.0/node_modules/class-variance-authority/dist/index.mjs
var dist = __webpack_require__(32420);
;// CONCATENATED MODULE: ./components/ui/badge.tsx




const badgeVariants = (0,dist/* cva */.j)("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
    variants: {
        variant: {
            default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/80",
            secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
            destructive: "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",
            outline: "text-foreground"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
function Badge({ className, variant, ...props }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (0,utils.cn)(badgeVariants({
            variant
        }), className),
        ...props
    });
}


;// CONCATENATED MODULE: ./components/cog/Card.tsx








const CogCard = ({ cog })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: `/cog/${cog?.user?.username}/${cog.slug}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Card, {
                    className: "duaration-300 relative h-44 space-y-4 p-6 transition duration-300 ease-in-out hover:cursor-pointer hover:bg-accent/25 active:scale-[0.98]",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CardHeader, {
                            className: "relative p-0",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-row items-center gap-x-3",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(avatar/* Avatar */.qE, {
                                            className: "h-7 w-7 rounded-sm",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(avatar/* AvatarImage */.F$, {
                                                    src: cog.imgUrl,
                                                    draggable: false
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(avatar/* AvatarFallback */.Q5, {
                                                    className: "h-7 w-7 rounded-sm",
                                                    children: cog.name.charAt(0).toUpperCase()
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(CardTitle, {
                                            className: (Card_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_default()).className + " truncate text-lg font-semibold",
                                            children: cog.name
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(CardDescription, {
                                    className: "line-clamp-2",
                                    children: cog.description
                                })
                            ]
                        }),
                        cog?.tags?.length > 0 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "z-50 flex flex-row flex-wrap gap-2",
                            children: cog.tags?.map((tag)=>/*#__PURE__*/ jsx_runtime_.jsx(Badge, {
                                    children: tag?.name
                                }, tag?.id))
                        }) : null
                    ]
                }, cog.id)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute bottom-0 right-0 z-50 m-3",
                children: /*#__PURE__*/ jsx_runtime_.jsx(UserHoverCard/* default */.ZP, {
                    user: cog?.user,
                    nameClass: "text-sm text-muted-foreground transition-colors duration-200 ease-in-out hover:cursor-pointer hover:text-accent-foreground"
                })
            })
        ]
    });
};
/* harmony default export */ const cog_Card = (CogCard);

;// CONCATENATED MODULE: ./app/page.tsx







async function Home() {
    const session = await (0,auth/* getAuthSession */.P)();
    const cogs = await prisma/* default */.Z.cog.findMany({
        include: {
            user: true,
            tags: true
        },
        where: {
            private: false
        },
        orderBy: {
            createdDate: "desc"
        }
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
        className: "md:pl-[240px]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(CoolBlur/* default */.ZP, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex h-full w-full flex-col items-center justify-center gap-8 p-0 pb-8",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mt-16 pb-4",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Logo/* default */.Z, {
                            size: "5xl"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full select-none px-8",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mb-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(QuickCreate, {
                                    session: session
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-4",
                                children: cogs.map((cog)=>/*#__PURE__*/ jsx_runtime_.jsx(cog_Card, {
                                        cog: cog
                                    }, cog?.id))
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 35982:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   F$: () => (/* binding */ e1),
/* harmony export */   Q5: () => (/* binding */ e2),
/* harmony export */   qE: () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1926);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/ayaanzaveri/Code/cognition/components/ui/avatar.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["Avatar"];

const e1 = proxy["AvatarImage"];

const e2 = proxy["AvatarFallback"];


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7942,8682,5935,6682,3201,9719,874,8708,9003,6298,9579,633,5741,6612,1266,4184], () => (__webpack_exec__(32046)));
module.exports = __webpack_exports__;

})();