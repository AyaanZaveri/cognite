(() => {
var exports = {};
exports.id = 8359;
exports.ids = [8359];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

"use strict";
module.exports = require("@prisma/client");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 63477:
/***/ ((module) => {

"use strict";
module.exports = require("querystring");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 27464:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(88204);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(39385);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(76905);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        'me',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 66051)), "/Users/ayaanzaveri/Code/cognition/app/me/page.tsx"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 200))).default(props)),(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 89876))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 42718)), "/Users/ayaanzaveri/Code/cognition/app/layout.tsx"],
'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6788)), "/Users/ayaanzaveri/Code/cognition/app/loading.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 200))).default(props)),(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 89876))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["/Users/ayaanzaveri/Code/cognition/app/me/page.tsx"];

    

    const originalPathname = "/me/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/me/page","pathname":"/me","bundlePath":"app/me/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 25884:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 82705, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12543));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 95741));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 17083))

/***/ }),

/***/ 17083:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ me_Card)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/font/google/target.css?{"path":"components/me/Card.tsx","import":"Space_Grotesk","arguments":[{"weight":["300","400","500","600","700"],"subsets":["latin"]}],"variableName":"space_grotesk"}
var Card_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_ = __webpack_require__(92603);
var Card_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_default = /*#__PURE__*/__webpack_require__.n(Card_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./lib/utils.ts
var utils = __webpack_require__(46006);
;// CONCATENATED MODULE: ./components/ui/card.tsx



const Card = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        ref: ref,
        className: (0,utils.cn)("rounded-lg border bg-card text-card-foreground shadow-sm", className),
        ...props
    }));
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        ref: ref,
        className: (0,utils.cn)("flex flex-col space-y-1.5 p-6", className),
        ...props
    }));
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("h3", {
        ref: ref,
        className: (0,utils.cn)("text-2xl font-semibold leading-none tracking-tight", className),
        ...props
    }));
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("p", {
        ref: ref,
        className: (0,utils.cn)("text-sm text-muted-foreground", className),
        ...props
    }));
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        ref: ref,
        className: (0,utils.cn)("p-6 pt-0", className),
        ...props
    }));
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        ref: ref,
        className: (0,utils.cn)(" flex items-center p-6 pt-0", className),
        ...props
    }));
CardFooter.displayName = "CardFooter";


// EXTERNAL MODULE: ./components/ui/avatar.tsx
var avatar = __webpack_require__(95741);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/link.js
var next_link = __webpack_require__(71930);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/.pnpm/@radix-ui+react-alert-dialog@1.0.4_@types+react-dom@18.2.4_@types+react@18.2.6_react-dom@18.2.0_react@18.2.0/node_modules/@radix-ui/react-alert-dialog/dist/index.mjs
var dist = __webpack_require__(26450);
// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(79271);
;// CONCATENATED MODULE: ./components/ui/alert-dialog.tsx
/* __next_internal_client_entry_do_not_use__ AlertDialog,AlertDialogTrigger,AlertDialogContent,AlertDialogHeader,AlertDialogFooter,AlertDialogTitle,AlertDialogDescription,AlertDialogAction,AlertDialogCancel auto */ 




const AlertDialog = dist/* Root */.fC;
const AlertDialogTrigger = dist/* Trigger */.xz;
const AlertDialogPortal = ({ className, ...props })=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Portal */.h_, {
        className: (0,utils.cn)(className),
        ...props
    });
AlertDialogPortal.displayName = dist/* Portal */.h_.displayName;
const AlertDialogOverlay = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Overlay */.aV, {
        className: (0,utils.cn)("fixed inset-0 z-50 bg-background/80 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
        ...props,
        ref: ref
    }));
AlertDialogOverlay.displayName = dist/* Overlay */.aV.displayName;
const AlertDialogContent = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(AlertDialogPortal, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(AlertDialogOverlay, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(dist/* Content */.VY, {
                ref: ref,
                className: (0,utils.cn)("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg md:w-full", className),
                ...props
            })
        ]
    }));
AlertDialogContent.displayName = dist/* Content */.VY.displayName;
const AlertDialogHeader = ({ className, ...props })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (0,utils.cn)("flex flex-col space-y-2 text-center sm:text-left", className),
        ...props
    });
AlertDialogHeader.displayName = "AlertDialogHeader";
const AlertDialogFooter = ({ className, ...props })=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (0,utils.cn)("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
        ...props
    });
AlertDialogFooter.displayName = "AlertDialogFooter";
const AlertDialogTitle = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Title */.Dx, {
        ref: ref,
        className: (0,utils.cn)("text-lg font-semibold", className),
        ...props
    }));
AlertDialogTitle.displayName = dist/* Title */.Dx.displayName;
const AlertDialogDescription = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Description */.dk, {
        ref: ref,
        className: (0,utils.cn)("text-sm text-muted-foreground", className),
        ...props
    }));
AlertDialogDescription.displayName = dist/* Description */.dk.displayName;
const AlertDialogAction = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Action */.aU, {
        ref: ref,
        className: (0,utils.cn)((0,ui_button/* buttonVariants */.d)(), className),
        ...props
    }));
AlertDialogAction.displayName = dist/* Action */.aU.displayName;
const AlertDialogCancel = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Cancel */.$j, {
        ref: ref,
        className: (0,utils.cn)((0,ui_button/* buttonVariants */.d)({
            variant: "outline"
        }), "mt-2 sm:mt-0", className),
        ...props
    }));
AlertDialogCancel.displayName = dist/* Cancel */.$j.displayName;


// EXTERNAL MODULE: ./components/ui/dropdown-menu.tsx
var dropdown_menu = __webpack_require__(51236);
// EXTERNAL MODULE: ./components/ui/use-toast.ts
var use_toast = __webpack_require__(57802);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-icons@4.10.1_react@18.2.0/node_modules/react-icons/tb/index.esm.js
var index_esm = __webpack_require__(96553);
// EXTERNAL MODULE: ./node_modules/.pnpm/lucide-react@0.260.0_react@18.2.0/node_modules/lucide-react/dist/cjs/lucide-react.js
var lucide_react = __webpack_require__(39850);
// EXTERNAL MODULE: ./node_modules/.pnpm/@radix-ui+react-context-menu@2.1.4_@types+react-dom@18.2.4_@types+react@18.2.6_react-dom@18.2.0_react@18.2.0/node_modules/@radix-ui/react-context-menu/dist/index.mjs
var react_context_menu_dist = __webpack_require__(35430);
;// CONCATENATED MODULE: ./components/ui/context-menu.tsx
/* __next_internal_client_entry_do_not_use__ ContextMenu,ContextMenuTrigger,ContextMenuContent,ContextMenuItem,ContextMenuCheckboxItem,ContextMenuRadioItem,ContextMenuLabel,ContextMenuSeparator,ContextMenuShortcut,ContextMenuGroup,ContextMenuPortal,ContextMenuSub,ContextMenuSubContent,ContextMenuSubTrigger,ContextMenuRadioGroup auto */ 




const ContextMenu = react_context_menu_dist/* Root */.fC;
const ContextMenuTrigger = react_context_menu_dist/* Trigger */.xz;
const ContextMenuGroup = react_context_menu_dist/* Group */.ZA;
const ContextMenuPortal = react_context_menu_dist/* Portal */.Uv;
const ContextMenuSub = react_context_menu_dist/* Sub */.Tr;
const ContextMenuRadioGroup = react_context_menu_dist/* RadioGroup */.Ee;
const ContextMenuSubTrigger = /*#__PURE__*/ react_.forwardRef(({ className, inset, children, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_context_menu_dist/* SubTrigger */.fF, {
        ref: ref,
        className: (0,utils.cn)("flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground", inset && "pl-8", className),
        ...props,
        children: [
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* ChevronRight */._Qn, {
                className: "ml-auto h-4 w-4"
            })
        ]
    }));
ContextMenuSubTrigger.displayName = react_context_menu_dist/* SubTrigger */.fF.displayName;
const ContextMenuSubContent = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_context_menu_dist/* SubContent */.tu, {
        ref: ref,
        className: (0,utils.cn)("z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", className),
        ...props
    }));
ContextMenuSubContent.displayName = react_context_menu_dist/* SubContent */.tu.displayName;
const ContextMenuContent = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_context_menu_dist/* Portal */.Uv, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_context_menu_dist/* Content */.VY, {
            ref: ref,
            className: (0,utils.cn)("z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md animate-in fade-in-80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", className),
            ...props
        })
    }));
ContextMenuContent.displayName = react_context_menu_dist/* Content */.VY.displayName;
const ContextMenuItem = /*#__PURE__*/ react_.forwardRef(({ className, inset, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_context_menu_dist/* Item */.ck, {
        ref: ref,
        className: (0,utils.cn)("relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", inset && "pl-8", className),
        ...props
    }));
ContextMenuItem.displayName = react_context_menu_dist/* Item */.ck.displayName;
const ContextMenuCheckboxItem = /*#__PURE__*/ react_.forwardRef(({ className, children, checked, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_context_menu_dist/* CheckboxItem */.oC, {
        ref: ref,
        className: (0,utils.cn)("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
        checked: checked,
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx(react_context_menu_dist/* ItemIndicator */.wU, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* Check */.JrY, {
                        className: "h-4 w-4"
                    })
                })
            }),
            children
        ]
    }));
ContextMenuCheckboxItem.displayName = react_context_menu_dist/* CheckboxItem */.oC.displayName;
const ContextMenuRadioItem = /*#__PURE__*/ react_.forwardRef(({ className, children, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_context_menu_dist/* RadioItem */.Rk, {
        ref: ref,
        className: (0,utils.cn)("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx(react_context_menu_dist/* ItemIndicator */.wU, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* Circle */.Cdc, {
                        className: "h-2 w-2 fill-current"
                    })
                })
            }),
            children
        ]
    }));
ContextMenuRadioItem.displayName = react_context_menu_dist/* RadioItem */.Rk.displayName;
const ContextMenuLabel = /*#__PURE__*/ react_.forwardRef(({ className, inset, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_context_menu_dist/* Label */.__, {
        ref: ref,
        className: (0,utils.cn)("px-2 py-1.5 text-sm font-semibold text-foreground", inset && "pl-8", className),
        ...props
    }));
ContextMenuLabel.displayName = react_context_menu_dist/* Label */.__.displayName;
const ContextMenuSeparator = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_context_menu_dist/* Separator */.Z0, {
        ref: ref,
        className: (0,utils.cn)("-mx-1 my-1 h-px bg-border", className),
        ...props
    }));
ContextMenuSeparator.displayName = react_context_menu_dist/* Separator */.Z0.displayName;
const ContextMenuShortcut = ({ className, ...props })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: (0,utils.cn)("ml-auto text-xs tracking-widest text-muted-foreground", className),
        ...props
    });
};
ContextMenuShortcut.displayName = "ContextMenuShortcut";


// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/navigation.js
var navigation = __webpack_require__(18424);
// EXTERNAL MODULE: ./components/Icons.tsx
var Icons = __webpack_require__(4925);
;// CONCATENATED MODULE: ./components/me/Card.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 













const MeCard = ({ cog, session })=>{
    const router = (0,navigation.useRouter)();
    const [showDeleteAlert, setShowDeleteAlert] = react_default().useState(false);
    const [isDeleteLoading, setIsDeleteLoading] = react_default().useState(false);
    const deleteCog = async (cogId)=>{
        const response = await fetch(`/api/cog/${cogId}`, {
            method: "DELETE"
        });
        if (response?.ok) {
            (0,use_toast/* toast */.Am)({
                title: "Cog deleted.",
                description: "Your cog was successfully deleted.",
                variant: "default"
            });
        }
        if (!response?.ok) {
            (0,use_toast/* toast */.Am)({
                title: "Something went wrong.",
                description: "Your cog was not deleted. Please try again.",
                variant: "destructive"
            });
        }
        return true;
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ContextMenu, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(ContextMenuTrigger, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: `/cog/${session?.user?.username}/${cog.slug}`,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Card, {
                                className: "duaration-300 relative h-44 p-6 transition duration-300 ease-in-out hover:cursor-pointer hover:bg-accent/25 active:scale-[0.98]",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CardHeader, {
                                    className: "relative p-0",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-row items-center gap-x-3",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(avatar.Avatar, {
                                                    className: "h-7 w-7 rounded-sm",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(avatar.AvatarImage, {
                                                            src: cog.imgUrl,
                                                            draggable: false
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(avatar.AvatarFallback, {
                                                            className: "h-7 w-7 rounded-sm",
                                                            children: cog.name.charAt(0).toUpperCase()
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(CardTitle, {
                                                    className: (Card_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_default()).className + " truncate text-lg font-semibold ",
                                                    children: cog.name
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(CardDescription, {
                                            className: "line-clamp-2",
                                            children: cog.description
                                        })
                                    ]
                                })
                            }, cog.id)
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ContextMenuContent, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ContextMenuItem, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: `/editor/${cog.id}`,
                                    className: "flex w-full",
                                    children: "Edit"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ContextMenuSeparator, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(ContextMenuItem, {
                                className: "flex cursor-pointer items-center text-destructive focus:text-destructive",
                                onSelect: ()=>setShowDeleteAlert(true),
                                children: "Delete"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute bottom-0 right-0 z-50 m-3",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dropdown_menu/* DropdownMenu */.h_, {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dropdown_menu/* DropdownMenuTrigger */.$F, {
                            className: "flex h-8 w-8 items-center justify-center rounded-md border transition-colors hover:bg-muted focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* MoreVertical */.hlC, {
                                    className: "h-4 w-4"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "sr-only",
                                    children: "Open"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dropdown_menu/* DropdownMenuContent */.AW, {
                            align: "end",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu/* DropdownMenuItem */.Xi, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: `/editor/${cog.id}`,
                                        className: "flex w-full",
                                        children: "Edit"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu/* DropdownMenuSeparator */.VD, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(dropdown_menu/* DropdownMenuItem */.Xi, {
                                    className: "flex cursor-pointer items-center text-destructive focus:text-destructive",
                                    onSelect: ()=>setShowDeleteAlert(true),
                                    children: "Delete"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(AlertDialog, {
                open: showDeleteAlert,
                onOpenChange: setShowDeleteAlert,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AlertDialogContent, {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AlertDialogHeader, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(AlertDialogTitle, {
                                    children: "Are you sure you want to delete this cog?"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(AlertDialogDescription, {
                                    children: "This action cannot be undone."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AlertDialogFooter, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(AlertDialogCancel, {
                                    children: "Cancel"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AlertDialogAction, {
                                    onClick: async (event)=>{
                                        event.preventDefault();
                                        setIsDeleteLoading(true);
                                        const deleted = await deleteCog(cog.id);
                                        if (deleted) {
                                            setIsDeleteLoading(false);
                                            setShowDeleteAlert(false);
                                            router.refresh();
                                        }
                                    },
                                    className: "bg-red-600 focus:ring-red-600",
                                    children: [
                                        isDeleteLoading ? /*#__PURE__*/ jsx_runtime_.jsx(Icons/* Icons */.P.spinner, {
                                            className: "mr-2 h-4 w-4 animate-spin"
                                        }) : /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* TbTrash */.EF5, {
                                            className: "mr-2 h-4 w-4"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "Delete"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const me_Card = (MeCard);


/***/ }),

/***/ 66051:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Page),
  dynamic: () => (/* binding */ dynamic)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./lib/auth.ts
var auth = __webpack_require__(66298);
;// CONCATENATED MODULE: ./utils/timestampDate.ts
const timestampDate = (timestamp)=>{
    const date = new Date(timestamp);
    function formatDate(date) {
        const monthNames = [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"
        ];
        const month = monthNames[date.getMonth()];
        const day = date.getDate();
        const year = date.getFullYear();
        return `${month} ${day}, ${year}`;
    }
    const formattedDate = formatDate(date);
    return formattedDate;
};
/* harmony default export */ const utils_timestampDate = (timestampDate);

// EXTERNAL MODULE: ./node_modules/.pnpm/lucide-react@0.260.0_react@18.2.0/node_modules/lucide-react/dist/cjs/lucide-react.js
var lucide_react = __webpack_require__(58795);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/image.js
var next_image = __webpack_require__(75376);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(49994);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-markdown@8.0.7_@types+react@18.2.6_react@18.2.0/node_modules/react-markdown/lib/react-markdown.js + 124 modules
var react_markdown = __webpack_require__(11434);
// EXTERNAL MODULE: ./components/ui/avatar.tsx
var avatar = __webpack_require__(35982);
// EXTERNAL MODULE: ./lib/prisma.ts
var prisma = __webpack_require__(43726);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1926);
;// CONCATENATED MODULE: ./components/me/Card.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/Users/ayaanzaveri/Code/cognition/components/me/Card.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Card = (__default__);
// EXTERNAL MODULE: ./components/CoolBlur.tsx
var CoolBlur = __webpack_require__(97675);
;// CONCATENATED MODULE: ./app/me/page.tsx











const dynamic = "force-dynamic";
async function Page() {
    const session = await (0,auth/* getAuthSession */.P)();
    const cogs = await prisma/* default */.Z.cog.findMany({
        include: {
            tags: true
        },
        where: {
            userId: session?.user?.id
        },
        orderBy: {
            createdDate: "desc"
        }
    });
    const date = utils_timestampDate(session?.user?.createdDate);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "p-0 md:pl-[240px]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(CoolBlur/* default */.ZP, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "-space-y-10 p-5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "relative h-48 w-full",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "https://i.ibb.co/r0nsc7X/Gradient-1.png",
                            alt: "Banner Image",
                            fill: true,
                            className: "rounded-xl object-cover",
                            draggable: false
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "ml-6 flex flex-col items-start justify-end",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "relative h-20 w-20 rounded-lg",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(avatar/* Avatar */.qE, {
                                    className: "h-20 w-20 rounded-xl ring-4 ring-white transition-all duration-200 ease-in-out hover:rotate-6 dark:ring-black",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(avatar/* AvatarImage */.F$, {
                                            src: session?.user.image,
                                            draggable: false
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(avatar/* AvatarFallback */.Q5, {
                                            className: "rounded-xl text-xl ring-4 ring-white transition-all duration-200 ease-in-out hover:rotate-6 dark:ring-black",
                                            children: session?.user?.username.charAt(0).toUpperCase()
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex items-center pt-3",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "text-xs text-muted-foreground",
                                        children: [
                                            "Joined ",
                                            date
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(lucide_react/* CalendarDays */.E_O, {
                                        className: "ml-1 h-3 w-3 text-muted-foreground"
                                    }),
                                    " "
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                className: `mt-1 text-3xl font-bold`,
                                children: [
                                    "@",
                                    session?.user?.username
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: `mt-1 text-muted-foreground`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(react_markdown/* ReactMarkdown */.D, {
                                    children: session?.user?.bio
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-full select-none px-8",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-4",
                    children: cogs.map((cog)=>/*#__PURE__*/ jsx_runtime_.jsx(Card, {
                            cog: cog,
                            session: session
                        }, cog?.id))
                })
            })
        ]
    });
}


/***/ }),

/***/ 35982:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   F$: () => (/* binding */ e1),
/* harmony export */   Q5: () => (/* binding */ e2),
/* harmony export */   qE: () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1926);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/ayaanzaveri/Code/cognition/components/ui/avatar.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["Avatar"];

const e1 = proxy["AvatarImage"];

const e2 = proxy["AvatarFallback"];


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7942,8682,5935,6682,9719,383,6298,5295,633,5741,4925], () => (__webpack_exec__(27464)));
module.exports = __webpack_exports__;

})();