(() => {
var exports = {};
exports.id = 5679;
exports.ids = [5679];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

"use strict";
module.exports = require("@prisma/client");

/***/ }),

/***/ 17804:
/***/ ((module) => {

"use strict";
module.exports = require("@prisma/client/scripts/default-index.js");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 77282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 63477:
/***/ ((module) => {

"use strict";
module.exports = require("querystring");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 25176:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(88204);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(39385);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(76905);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        'cog',
        {
        children: [
        '[user]',
        {
        children: [
        '[slug]',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 18128)), "/Users/ayaanzaveri/Code/cognition/app/cog/[user]/[slug]/page.tsx"],
          
        }]
      },
        {
          'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 36520)), "/Users/ayaanzaveri/Code/cognition/app/cog/[user]/[slug]/loading.tsx"],
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 200))).default(props)),(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 89876))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 42718)), "/Users/ayaanzaveri/Code/cognition/app/layout.tsx"],
'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6788)), "/Users/ayaanzaveri/Code/cognition/app/loading.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 200))).default(props)),(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 89876))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["/Users/ayaanzaveri/Code/cognition/app/cog/[user]/[slug]/page.tsx"];

    

    const originalPathname = "/cog/[user]/[slug]/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/cog/[user]/[slug]/page","pathname":"/cog/[user]/[slug]","bundlePath":"app/cog/[user]/[slug]/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 86153:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 82705, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 95618, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12543));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 33082));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 75215))

/***/ }),

/***/ 53034:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 95618, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 82705, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12543))

/***/ }),

/***/ 33082:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Chat)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/font/google/target.css?{"path":"components/Chat.tsx","import":"Space_Grotesk","arguments":[{"weight":["300","400","500","600","700"],"subsets":["latin"]}],"variableName":"space_grotesk"}
var Chat_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_ = __webpack_require__(38391);
var Chat_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_default = /*#__PURE__*/__webpack_require__.n(Chat_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_);
// EXTERNAL MODULE: ./node_modules/.pnpm/remark-gfm@3.0.1/node_modules/remark-gfm/index.js + 30 modules
var remark_gfm = __webpack_require__(91580);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-markdown@8.0.7_@types+react@18.2.6_react@18.2.0/node_modules/react-markdown/lib/react-markdown.js + 108 modules
var react_markdown = __webpack_require__(77355);
// EXTERNAL MODULE: ./node_modules/.pnpm/ai@2.1.33_react@18.2.0_solid-js@1.7.8_svelte@4.1.1_vue@3.3.4/node_modules/ai/react/dist/index.mjs + 3 modules
var dist = __webpack_require__(79840);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/font/google/target.css?{"path":"components/ChatBox.tsx","import":"Space_Grotesk","arguments":[{"subsets":["latin"]}],"variableName":"space_grotesk"}
var ChatBox_tsx_import_Space_Grotesk_arguments_subsets_latin_variableName_space_grotesk_ = __webpack_require__(96802);
var ChatBox_tsx_import_Space_Grotesk_arguments_subsets_latin_variableName_space_grotesk_default = /*#__PURE__*/__webpack_require__.n(ChatBox_tsx_import_Space_Grotesk_arguments_subsets_latin_variableName_space_grotesk_);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./components/ui/input.tsx
var ui_input = __webpack_require__(40741);
// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(79271);
;// CONCATENATED MODULE: ./components/ChatBox.tsx





const ChatBox = ({ input, handleInputChange, handleThinking, isThinking, isStreaming })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
        className: "flex w-full flex-row gap-3",
        onSubmit: handleThinking,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ui_input/* Input */.I, {
                name: "",
                id: "",
                value: input,
                onChange: handleInputChange,
                placeholder: "What would you like to cognite \uD83D\uDD25",
                className: "h-12 bg-background/50 text-base backdrop-blur-md"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                type: "submit",
                className: `m-0 h-12 px-6 text-base md:mr-[240px] ${(ChatBox_tsx_import_Space_Grotesk_arguments_subsets_latin_variableName_space_grotesk_default()).className}`,
                children: isStreaming && isThinking ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                    className: "inline-flex animate-pulse gap-2",
                    children: [
                        "Going ",
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "\uD83D\uDE80"
                        })
                    ]
                }) : isThinking && !isStreaming ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                    className: "inline-flex animate-pulse gap-2",
                    children: [
                        "Thinking ",
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "\uD83E\uDDE0"
                        })
                    ]
                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                    className: "inline-flex gap-2",
                    children: [
                        "Cognite ",
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "⚡️"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const components_ChatBox = (ChatBox);

// EXTERNAL MODULE: ./lib/utils.ts
var utils = __webpack_require__(46006);
// EXTERNAL MODULE: ./node_modules/.pnpm/@radix-ui+react-tabs@1.0.4_@types+react-dom@18.2.4_@types+react@18.2.6_react-dom@18.2.0_react@18.2.0/node_modules/@radix-ui/react-tabs/dist/index.mjs
var react_tabs_dist = __webpack_require__(24585);
;// CONCATENATED MODULE: ./components/ui/tabs.tsx
/* __next_internal_client_entry_do_not_use__ Tabs,TabsList,TabsTrigger,TabsContent auto */ 



const Tabs = react_tabs_dist/* Root */.fC;
const TabsList = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_tabs_dist/* List */.aV, {
        ref: ref,
        className: (0,utils.cn)("inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground", className),
        ...props
    }));
TabsList.displayName = react_tabs_dist/* List */.aV.displayName;
const TabsTrigger = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_tabs_dist/* Trigger */.xz, {
        ref: ref,
        className: (0,utils.cn)("inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow", className),
        ...props
    }));
TabsTrigger.displayName = react_tabs_dist/* Trigger */.xz.displayName;
const TabsContent = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_tabs_dist/* Content */.VY, {
        ref: ref,
        className: (0,utils.cn)("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
        ...props
    }));
TabsContent.displayName = react_tabs_dist/* Content */.VY.displayName;


// EXTERNAL MODULE: ./node_modules/.pnpm/class-variance-authority@0.7.0/node_modules/class-variance-authority/dist/index.mjs
var class_variance_authority_dist = __webpack_require__(75237);
;// CONCATENATED MODULE: ./components/ui/badge.tsx




const badgeVariants = (0,class_variance_authority_dist/* cva */.j)("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
    variants: {
        variant: {
            default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/80",
            secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
            destructive: "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",
            outline: "text-foreground"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
function Badge({ className, variant, ...props }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (0,utils.cn)(badgeVariants({
            variant
        }), className),
        ...props
    });
}


;// CONCATENATED MODULE: ./components/Chat.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 









function Chat({ id }) {
    const [isThinking, setIsThinking] = (0,react_.useState)(false);
    const [isStreaming, setIsStreaming] = (0,react_.useState)(false);
    const [selectedStyle, setSelectedStyle] = (0,react_.useState)("neutral");
    const { messages, input, handleInputChange, handleSubmit } = (0,dist/* useChat */.R)({
        api: "/api/cog/completions",
        body: {
            id: id,
            style: selectedStyle
        },
        onError: (err)=>{
            console.log(err);
        },
        onResponse: (res)=>{
            setIsStreaming(true);
        },
        onFinish: (msg)=>{
            setIsStreaming(false);
            setIsThinking(false);
        }
    });
    const handleThinking = (e, chatRequestOptions)=>{
        setIsThinking(true);
        handleSubmit(e, chatRequestOptions);
    };
    const styles = [
        {
            id: "friendly",
            name: "Friendly \uD83D\uDC4B",
            description: "A nice and friendly conversation style."
        },
        {
            id: "neutral",
            name: "Neutral \uD83E\uDD14",
            description: "A casual and neutral conversation style."
        },
        {
            id: "focused",
            name: "Focused \uD83E\uDDE0",
            description: "A very precise and focused conversation style."
        }
    ];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "pb-28",
        children: [
            messages.length === 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `mt-20 flex flex-col items-center gap-y-3`,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `${(Chat_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_default()).className} space-x-1.5`,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "font-medium",
                                children: "Pick a conversation style"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Badge, {
                                variant: "secondary",
                                className: "select-none text-accent-foreground/70",
                                children: "BETA"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Tabs, {
                        defaultValue: "neutral",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(TabsList, {
                            children: styles.map((style)=>/*#__PURE__*/ jsx_runtime_.jsx(TabsTrigger, {
                                    value: style.id,
                                    onClick: ()=>setSelectedStyle(style.id),
                                    children: style.name
                                }, style.id))
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex w-full flex-col gap-5 px-8",
                children: messages.map((message)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (0,utils.cn)("flex w-max max-w-[75%] flex-col gap-2 rounded-lg px-4 py-3", message.role === "user" ? "ml-auto bg-primary text-primary-foreground shadow-xl shadow-primary/20" : "bg-muted shadow-xl shadow-muted/20"),
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "prose transition-all",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_markdown/* ReactMarkdown */.D, {
                                remarkPlugins: [
                                    remark_gfm/* default */.Z
                                ],
                                children: message.content
                            })
                        })
                    }, message.id))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "fixed bottom-6 w-full",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex w-full flex-row gap-6 px-8",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(components_ChatBox, {
                        input: input,
                        handleInputChange: handleInputChange,
                        handleThinking: handleThinking,
                        isThinking: isThinking,
                        isStreaming: isStreaming
                    })
                })
            })
        ]
    });
}


/***/ }),

/***/ 40741:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   I: () => (/* binding */ Input)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46006);



const Input = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, type, ...props }, ref)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
        type: type,
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background transition duration-200 ease-in-out file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50", className),
        ref: ref,
        ...props
    });
});
Input.displayName = "Input";



/***/ }),

/***/ 36520:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Loading)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./components/CoolBlur.tsx
var CoolBlur = __webpack_require__(97675);
// EXTERNAL MODULE: ./components/Logo.tsx
var Logo = __webpack_require__(91266);
// EXTERNAL MODULE: ./lib/utils.ts
var utils = __webpack_require__(90430);
;// CONCATENATED MODULE: ./components/ui/skeleton.tsx


function Skeleton({ className, ...props }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (0,utils.cn)("animate-pulse rounded-md bg-primary/10", className),
        ...props
    });
}


// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/link.js
var next_link = __webpack_require__(33270);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./app/cog/[user]/[slug]/loading.tsx





function Loading() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "p-0 md:pl-[240px]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(CoolBlur/* default */.ZP, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "p-5",
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Logo/* default */.Z, {
                        size: "3xl"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col items-center justify-center gap-6 p-5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                        className: "animate-pulse-[3s] h-28 w-28 rounded-lg"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex w-full flex-col items-center gap-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                                className: `h-10 w-3/4`
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex w-full flex-col items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                                        className: "h-4 w-2/3"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                                        className: "mt-4 h-4 w-36"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "fixed bottom-6 w-full",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex w-full flex-row gap-3 px-8",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                            className: "h-12 w-full"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Skeleton, {
                            className: "h-12 w-44 md:mr-[240px]"
                        })
                    ]
                })
            })
        ]
    });
}


/***/ }),

/***/ 18128:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Page),
  dynamic: () => (/* binding */ dynamic)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/font/google/target.css?{"path":"app/cog/[user]/[slug]/page.tsx","import":"Space_Grotesk","arguments":[{"weight":["300","400","500","600","700"],"subsets":["latin"]}],"variableName":"space_grotesk"}
var page_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_ = __webpack_require__(47766);
var page_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_default = /*#__PURE__*/__webpack_require__.n(page_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_);
// EXTERNAL MODULE: ./components/Logo.tsx
var Logo = __webpack_require__(91266);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/image.js
var next_image = __webpack_require__(75376);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1926);
;// CONCATENATED MODULE: ./components/Chat.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/Users/ayaanzaveri/Code/cognition/components/Chat.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Chat = (__default__);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/link.js
var next_link = __webpack_require__(33270);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/UserHoverCard.tsx
var UserHoverCard = __webpack_require__(37427);
// EXTERNAL MODULE: ./lib/auth.ts
var auth = __webpack_require__(66298);
// EXTERNAL MODULE: ./components/CoolBlur.tsx
var CoolBlur = __webpack_require__(97675);
// EXTERNAL MODULE: external "@prisma/client"
var client_ = __webpack_require__(53524);
// EXTERNAL MODULE: ./node_modules/.pnpm/@prisma+extension-accelerate@0.5.0_@prisma+client@5.1.1/node_modules/@prisma/extension-accelerate/dist/esm/index.js + 2 modules
var esm = __webpack_require__(17524);
;// CONCATENATED MODULE: ./app/cog/[user]/[slug]/page.tsx











const dynamic = "force-dynamic";
const prismaWithAccelerate = new client_.PrismaClient().$extends((0,esm/* withAccelerate */.z)());
async function getCog(username, slug, session) {
    const cog = await prismaWithAccelerate.cog.findFirst({
        where: {
            slug: slug,
            user: {
                username: username
            },
            OR: [
                {
                    private: false
                },
                {
                    private: true,
                    userId: session?.user?.id ? session.user.id : "bob"
                }
            ]
        },
        include: {
            user: true
        }
    });
    return cog;
}
async function Page({ params }) {
    const { user, slug } = params;
    const session = await (0,auth/* getAuthSession */.P)();
    const cog = await getCog(user, slug, session);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "p-0 md:pl-[240px]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(CoolBlur/* default */.ZP, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "p-5",
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Logo/* default */.Z, {
                        size: "3xl"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col items-center justify-center gap-6 p-5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: cog?.imgUrl,
                        alt: cog?.slug,
                        unoptimized: true,
                        width: 128,
                        height: 128,
                        draggable: false,
                        className: "rounded-lg transition-all duration-1000 ease-in-out hover:scale-110"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col items-center gap-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: `text-center text-5xl font-bold sm:text-6xl md:text-7xl ${(page_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_default()).className}`,
                                children: cog?.name
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-center text-lg text-muted-foreground",
                                        children: cog?.description
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "text-accent-foreground",
                                        children: [
                                            "Created by",
                                            " ",
                                            /*#__PURE__*/ jsx_runtime_.jsx(UserHoverCard/* default */.ZP, {
                                                user: cog?.user,
                                                nameClass: "cursor-pointer font-semibold transition-colors duration-300 ease-in-out hover:text-orange-500 active:text-orange-500"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Chat, {
                id: cog?.id
            })
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7942,8682,5935,6682,7524,874,6650,6298,5714,633,5741,1266,4184], () => (__webpack_exec__(25176)));
module.exports = __webpack_exports__;

})();