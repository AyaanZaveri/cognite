(() => {
var exports = {};
exports.id = 1572;
exports.ids = [1572];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

"use strict";
module.exports = require("@prisma/client");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 93977:
/***/ ((module) => {

"use strict";
module.exports = require("node:fs/promises");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 63477:
/***/ ((module) => {

"use strict";
module.exports = require("querystring");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 55967:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport safe */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__.GlobalError),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(88204);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(39385);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(76905);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_2__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    

    const tree = {
        children: [
        '',
        {
        children: [
        'create',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 85635)), "/Users/ayaanzaveri/Code/cognition/app/create/page.tsx"],
          
        }]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 200))).default(props)),(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 89876))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 42718)), "/Users/ayaanzaveri/Code/cognition/app/layout.tsx"],
'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6788)), "/Users/ayaanzaveri/Code/cognition/app/loading.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 200))).default(props)),(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 89876))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["/Users/ayaanzaveri/Code/cognition/app/create/page.tsx"];

    

    const originalPathname = "/create/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    

    // Create and export the route module that will be consumed.
    const options = {"definition":{"kind":"APP_PAGE","page":"/create/page","pathname":"/create","bundlePath":"app/create/page","filename":"","appPaths":[]}}
    const routeModule = new (next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default())({
      ...options,
      userland: {
        loaderTree: tree,
      },
    })
  

/***/ }),

/***/ 70057:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12543));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 31229))

/***/ }),

/***/ 31229:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ cog_Create)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/font/google/target.css?{"path":"components/cog/Create.tsx","import":"Space_Grotesk","arguments":[{"weight":["300","400","500","600","700"],"subsets":["latin"]}],"variableName":"space_grotesk"}
var Create_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_ = __webpack_require__(20753);
var Create_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_default = /*#__PURE__*/__webpack_require__.n(Create_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_);
// EXTERNAL MODULE: ./node_modules/.pnpm/@hookform+resolvers@3.1.1_react-hook-form@7.45.2/node_modules/@hookform/resolvers/zod/dist/zod.mjs + 1 modules
var zod = __webpack_require__(54142);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-hook-form@7.45.2_react@18.2.0/node_modules/react-hook-form/dist/index.esm.mjs
var index_esm = __webpack_require__(52653);
// EXTERNAL MODULE: ./node_modules/.pnpm/zod@3.21.4/node_modules/zod/lib/index.mjs
var lib = __webpack_require__(43018);
// EXTERNAL MODULE: ./components/ui/form.tsx + 1 modules
var ui_form = __webpack_require__(50811);
// EXTERNAL MODULE: ./components/ui/textarea.tsx
var ui_textarea = __webpack_require__(21892);
// EXTERNAL MODULE: ./components/ui/input.tsx
var input = __webpack_require__(40741);
// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(79271);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./lib/utils.ts
var utils = __webpack_require__(46006);
// EXTERNAL MODULE: ./utils/scrapeSite.ts
var scrapeSite = __webpack_require__(60919);
// EXTERNAL MODULE: ./node_modules/.pnpm/langchain@0.0.120_@huggingface+inference@1.8.0_@pinecone-database+pinecone@0.1.6_axios@1.4.0__er7fjrb2atfoegdcu2uwzeynna/node_modules/langchain/text_splitter.js
var text_splitter = __webpack_require__(8962);
// EXTERNAL MODULE: ./node_modules/.pnpm/langchain@0.0.120_@huggingface+inference@1.8.0_@pinecone-database+pinecone@0.1.6_axios@1.4.0__er7fjrb2atfoegdcu2uwzeynna/node_modules/langchain/document_loaders/fs/pdf.js + 4 modules
var pdf = __webpack_require__(87367);
// EXTERNAL MODULE: ./node_modules/.pnpm/slugify@1.6.6/node_modules/slugify/slugify.js
var slugify = __webpack_require__(56630);
var slugify_default = /*#__PURE__*/__webpack_require__.n(slugify);
// EXTERNAL MODULE: ./node_modules/.pnpm/axios@1.4.0/node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(30386);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/link.js
var next_link = __webpack_require__(71930);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/.pnpm/@radix-ui+react-switch@1.0.3_@types+react-dom@18.2.4_@types+react@18.2.6_react-dom@18.2.0_react@18.2.0/node_modules/@radix-ui/react-switch/dist/index.mjs + 1 modules
var dist = __webpack_require__(86434);
;// CONCATENATED MODULE: ./components/ui/switch.tsx
/* __next_internal_client_entry_do_not_use__ Switch auto */ 



const Switch = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Root */.fC, {
        className: (0,utils.cn)("peer inline-flex h-[20px] w-[36px] shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input", className),
        ...props,
        ref: ref,
        children: /*#__PURE__*/ jsx_runtime_.jsx(dist/* Thumb */.bU, {
            className: (0,utils.cn)("pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0")
        })
    }));
Switch.displayName = dist/* Root */.fC.displayName;


// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/navigation.js
var navigation = __webpack_require__(18424);
;// CONCATENATED MODULE: ./components/cog/Create.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


















const MAX_FILE_SIZE = 5000000; // 5MB
const tagsSchema = lib/* array */.IX(lib/* object */.Ry({
    value: lib/* string */.Z_().min(2, {
        message: "Tag must be at least 2 characters long"
    }).max(20, {
        message: "Tag must be at most 20 characters long"
    })
})).optional();
const createFormSchema = lib/* object */.Ry({
    name: lib/* string */.Z_().min(3, {
        message: "Your name must be at least 3 characters long"
    }).max(30, {
        message: "It's a name, not a poem (max 30 characters)"
    }),
    description: lib/* string */.Z_().max(300, {
        message: "It's a description, not an essay (max 300 characters)"
    }).optional(),
    imgUrl: lib/* string */.Z_().max(200, {
        message: "Your image URL is too long (max 200 characters)"
    }).optional(),
    tags: tagsSchema,
    websites: lib/* array */.IX(lib/* object */.Ry({
        value: lib/* string */.Z_().url({
            message: "Please enter a valid URL."
        })
    })).optional(),
    file: lib/* string */.Z_().optional(),
    private: lib/* boolean */.O7().optional()
});
const Create = (session)=>{
    const form = (0,index_esm/* useForm */.cI)({
        resolver: (0,zod/* zodResolver */.F)(createFormSchema),
        mode: "onChange"
    });
    const { fields: tagFields, append: appendTag } = (0,index_esm/* useFieldArray */.Dq)({
        name: "tags",
        control: form.control
    });
    const { fields: websiteFields, append: appendWebsite } = (0,index_esm/* useFieldArray */.Dq)({
        name: "websites",
        control: form.control
    });
    const [buttonStatus, setButtonStatus] = (0,react_.useState)({
        text: "Create",
        disabled: false,
        pulse: false
    });
    const router = (0,navigation.useRouter)();
    const [file, setFile] = (0,react_.useState)(null);
    async function getSources(sources) {
        try {
            if (sources?.sites.length > 0 || file) {
                setButtonStatus({
                    text: "Getting sources \uD83C\uDF0E",
                    disabled: true,
                    pulse: true
                });
                // console.log(sources);
                const docs = [];
                if (sources?.sites && sources?.sites.length > 0) {
                    const siteText = await (0,scrapeSite/* scrapeSite */.T)(sources?.sites);
                    // console.log(siteText);
                    const splitter = new text_splitter/* RecursiveCharacterTextSplitter */.s9({
                        chunkSize: 1000,
                        chunkOverlap: 200
                    });
                    const siteDocs = await splitter.createDocuments([
                        siteText
                    ]);
                    docs.push(...siteDocs);
                }
                if (file) {
                    const splitter = new text_splitter/* RecursiveCharacterTextSplitter */.s9({
                        chunkSize: 1000,
                        chunkOverlap: 200
                    });
                    const loader = new pdf/* PDFLoader */.u(file);
                    const pdfDocs = await loader.loadAndSplit(splitter);
                    docs.push(...pdfDocs);
                }
                // console.log(docs);
                setButtonStatus({
                    text: "Creating cog \uD83E\uDDE0",
                    disabled: true,
                    pulse: true
                });
                return docs;
            } else {
                setButtonStatus({
                    text: "No sources provided \uD83D\uDE22",
                    disabled: false,
                    pulse: false
                });
            }
        } catch (error) {
            console.log("error", error);
            setButtonStatus({
                text: "Error getting sources \uD83D\uDE22",
                disabled: false,
                pulse: false
            });
        }
    }
    async function onSubmit(data) {
        const sources = {
            sites: data.websites?.map((website)=>website.value),
            files: data.file
        };
        const theDocs = await getSources(sources);
        const updatedData = {
            name: data.name,
            description: data.description,
            imgUrl: data.imgUrl,
            tags: data.tags?.map((tag)=>tag.value),
            docs: theDocs,
            slug: slugify_default()(data.name, {
                lower: true
            }),
            userId: session?.session?.user?.id,
            isPrivate: data.private
        };
        // console.log(session?.session?.user?.id);
        const response = await axios/* default */.Z.post(`/api/cog/create`, {
            data: updatedData
        }).then((res)=>{
            // console.log(res);
            setButtonStatus({
                text: "Cog created! \uD83C\uDF89",
                disabled: true,
                pulse: false
            });
            router.push(`/cog/${session?.session?.user.username}/${res.data.cog.slug}`);
        }).catch((err)=>{
            setButtonStatus({
                text: "Error creating cog \uD83D\uDE22",
                disabled: false,
                pulse: false
            });
            console.log(err);
        });
    }
    const handleFile = async (event)=>{
        if (event.target.files) {
            try {
                const file = event.target.files?.[0];
                if (file) {
                    const arrayBuffer = await file.arrayBuffer();
                    const blob = new Blob([
                        new Uint8Array(arrayBuffer)
                    ], {
                        type: file.type
                    });
                    setFile(blob);
                }
            } catch (err) {
                console.log("err", err);
            }
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "space-y-8",
        children: /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* Form */.l0, {
            ...form,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                className: "space-y-4",
                onSubmit: form.handleSubmit(onSubmit),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormField */.Wi, {
                        control: form.control,
                        name: "name",
                        render: ({ field })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_form/* FormItem */.xJ, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormLabel */.lX, {
                                        children: "Name"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormControl */.NI, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(input/* Input */.I, {
                                            placeholder: "Name",
                                            ...field
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormDescription */.pf, {
                                        children: "This is the name of the cog."
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormMessage */.zG, {})
                                ]
                            })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            websiteFields.map((field, index)=>/*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormField */.Wi, {
                                    control: form.control,
                                    name: `websites.${index}.value`,
                                    render: ({ field })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_form/* FormItem */.xJ, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormLabel */.lX, {
                                                    className: (0,utils.cn)(index !== 0 && "sr-only"),
                                                    children: "Websites"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormDescription */.pf, {
                                                    className: (0,utils.cn)(index !== 0 && "sr-only"),
                                                    children: "Websites you want to train the cog on."
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormControl */.NI, {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(input/* Input */.I, {
                                                        ...field
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormMessage */.zG, {})
                                            ]
                                        })
                                }, field.id)),
                            /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                type: "button",
                                variant: "outline",
                                size: "sm",
                                className: "mt-2",
                                onClick: ()=>appendWebsite({
                                        value: ""
                                    }),
                                children: "Add Website"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormField */.Wi, {
                        control: form.control,
                        name: "file",
                        render: ({ field })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_form/* FormItem */.xJ, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormLabel */.lX, {
                                        children: "Files"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormControl */.NI, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(input/* Input */.I, {
                                            type: "file",
                                            placeholder: "File",
                                            ...field,
                                            onChange: handleFile
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormDescription */.pf, {
                                        children: "You can also upload a PDF"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormMessage */.zG, {})
                                ]
                            })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormField */.Wi, {
                        control: form.control,
                        name: "private",
                        render: ({ field })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_form/* FormItem */.xJ, {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "inline-flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormLabel */.lX, {
                                                children: "Private"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormControl */.NI, {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Switch, {
                                                    checked: field.value,
                                                    onCheckedChange: field.onChange
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormDescription */.pf, {
                                        children: field.value ? "Your cog is private ~ Only you can see it \uD83D\uDC40" : "Your cog is public ~ It can be discovered \uD83C\uDF0E"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormMessage */.zG, {})
                                ]
                            })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormField */.Wi, {
                        control: form.control,
                        name: "description",
                        render: ({ field })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_form/* FormItem */.xJ, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormLabel */.lX, {
                                        children: "Description"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormControl */.NI, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ui_textarea/* Textarea */.g, {
                                            placeholder: "Description",
                                            ...field
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormDescription */.pf, {
                                        children: "A short description of the cog."
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormMessage */.zG, {})
                                ]
                            })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            tagFields.map((field, index)=>/*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormField */.Wi, {
                                    control: form.control,
                                    name: `tags.${index}.value`,
                                    render: ({ field })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_form/* FormItem */.xJ, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormLabel */.lX, {
                                                    className: (0,utils.cn)(index !== 0 && "sr-only"),
                                                    children: "Tags"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormDescription */.pf, {
                                                    className: (0,utils.cn)(index !== 0 && "sr-only"),
                                                    children: "Tags are used to help people find your cog."
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormControl */.NI, {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(input/* Input */.I, {
                                                        ...field
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormMessage */.zG, {
                                                    children: form.formState.errors.tags?.[index]?.value?.message
                                                })
                                            ]
                                        })
                                }, field.id)),
                            /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                type: "button",
                                variant: "outline",
                                size: "sm",
                                className: "mt-2",
                                onClick: ()=>appendTag({
                                        value: ""
                                    }),
                                children: "Add Tag"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormField */.Wi, {
                        control: form.control,
                        name: "imgUrl",
                        render: ({ field })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_form/* FormItem */.xJ, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormLabel */.lX, {
                                        children: "Image URL"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormControl */.NI, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(input/* Input */.I, {
                                            placeholder: "Image URL",
                                            ...field
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormDescription */.pf, {
                                        children: "A URL to an image of the cog."
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormMessage */.zG, {})
                                ]
                            })
                    }),
                    session?.session?.user?.id ? /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                        type: "submit",
                        className: `${(Create_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_default()).className}`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (0,utils.cn)(buttonStatus.pulse && "animate-pulse", buttonStatus.disabled && "cursor-not-allowed"),
                            children: buttonStatus.text
                        })
                    }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/api/auth/signin",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                type: "button",
                                className: `${(Create_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_default()).className}`,
                                children: "Sign in to create a cog"
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const cog_Create = (Create);


/***/ }),

/***/ 21892:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   g: () => (/* binding */ Textarea)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46006);



const Textarea = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
        className: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_2__.cn)("flex min-h-[80px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm ring-offset-background transition duration-200 ease-in-out placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50", className),
        ref: ref,
        ...props
    });
});
Textarea.displayName = "Textarea";



/***/ }),

/***/ 60919:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   T: () => (/* binding */ scrapeSite)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(30386);

const scrapeSite = async (urls)=>{
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.post("/api/extract", {
            urls
        });
        console.log("response", response);
        return response.data.extracted_text;
    } catch (err) {
        if (err instanceof Error) {
            console.log(err.message);
        } else {
            console.log("Unexpected error", err);
        }
    }
};


/***/ }),

/***/ 85635:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page),
  dynamic: () => (/* binding */ dynamic)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/font/google/target.css?{"path":"app/create/page.tsx","import":"Space_Grotesk","arguments":[{"weight":["300","400","500","600","700"],"subsets":["latin"]}],"variableName":"space_grotesk"}
var page_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_ = __webpack_require__(32652);
var page_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_default = /*#__PURE__*/__webpack_require__.n(page_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1926);
;// CONCATENATED MODULE: ./components/cog/Create.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/Users/ayaanzaveri/Code/cognition/components/cog/Create.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Create = (__default__);
// EXTERNAL MODULE: ./components/CoolBlur.tsx
var CoolBlur = __webpack_require__(97675);
// EXTERNAL MODULE: ./lib/auth.ts
var auth = __webpack_require__(66298);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.12_@babel+core@7.22.9_react-dom@18.2.0_react@18.2.0/node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(49994);
;// CONCATENATED MODULE: ./app/create/page.tsx






const dynamic = "force-dynamic";
const Page = async ()=>{
    const session = await (0,auth/* getAuthSession */.P)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "p-0 md:pl-[240px]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(CoolBlur/* default */.ZP, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col gap-4 px-8 py-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: `${(page_tsx_import_Space_Grotesk_arguments_weight_300_400_500_600_700_subsets_latin_variableName_space_grotesk_default()).className} animate-text bg-gradient-to-r from-orange-500 via-amber-500 to-red-500 bg-clip-text pb-2 text-4xl font-semibold text-transparent`,
                        children: "Create"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Create, {
                        session: session
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7942,8682,5935,3201,8708,7648,6298,5714,633,6612], () => (__webpack_exec__(55967)));
module.exports = __webpack_exports__;

})();